const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET || "development-secret-change-me";
const DB = path.join(__dirname, "..", "database", "db.json");

app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use("/customer", express.static(path.join(__dirname, "..", "customer")));
app.use("/admin", express.static(path.join(__dirname, "..", "admin")));
app.get("/", (_, res) => res.redirect("/customer"));

function readDB() {
  return JSON.parse(fs.readFileSync(DB, "utf8"));
}
function writeDB(data) {
  fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}
function tokenFor(user) {
  return jwt.sign({ id: user.id, role: user.role, email: user.email }, SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const raw = req.headers.authorization || "";
  try {
    req.user = jwt.verify(raw.replace(/^Bearer\s+/i, ""), SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Please log in first." });
  }
}
function adminOnly(req, res, next) {
  if (req.user?.role !== "admin") return res.status(403).json({ error: "Admin access required." });
  next();
}
function safeUser(u) {
  const { password, ...rest } = u;
  return rest;
}

app.get("/api/health", (_, res) => res.json({ ok: true, app: "BibekShop API" }));
app.get("/api/products", (req, res) => {
  const db = readDB();
  let items = db.products.filter(p => p.active !== false);
  if (req.query.category && req.query.category !== "All") items = items.filter(p => p.category === req.query.category);
  if (req.query.q) {
    const q = String(req.query.q).toLowerCase();
    items = items.filter(p => (p.name + " " + p.description + " " + p.category).toLowerCase().includes(q));
  }
  res.json(items);
});
app.post("/api/register", async (req, res) => {
  const { name, email, password, phone } = req.body || {};
  if (!name || !email || !password || password.length < 6) return res.status(400).json({ error: "Name, email and password (at least 6 characters) are required." });
  const db = readDB();
  if (db.users.some(u => u.email.toLowerCase() === String(email).toLowerCase())) return res.status(409).json({ error: "Email already registered." });
  const user = { id: "u_" + Date.now(), name, email: String(email).toLowerCase(), phone: phone || "", password: await bcrypt.hash(password, 10), role: "customer", createdAt: new Date().toISOString() };
  db.users.push(user); writeDB(db);
  res.status(201).json({ token: tokenFor(user), user: safeUser(user) });
});
app.post("/api/login", async (req, res) => {
  const { email, password } = req.body || {};
  const db = readDB();
  const user = db.users.find(u => u.email.toLowerCase() === String(email || "").toLowerCase());
  if (!user || !(await bcrypt.compare(password || "", user.password))) return res.status(401).json({ error: "Email or password is incorrect." });
  res.json({ token: tokenFor(user), user: safeUser(user) });
});
app.get("/api/me", auth, (req, res) => {
  const user = readDB().users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: "User not found." });
  res.json(safeUser(user));
});
app.post("/api/orders", auth, (req, res) => {
  if (req.user.role !== "customer") return res.status(403).json({ error: "Customer account required." });
  const { items, address, phone, paymentMethod } = req.body || {};
  if (!Array.isArray(items) || !items.length || !address || !phone) return res.status(400).json({ error: "Cart, delivery address and phone are required." });
  const db = readDB();
  const lines = [];
  for (const line of items) {
    const p = db.products.find(x => x.id === line.productId && x.active !== false);
    const qty = Math.max(1, Math.min(99, Number(line.quantity) || 1));
    if (!p || p.stock < qty) return res.status(400).json({ error: `Product unavailable or insufficient stock: ${p?.name || "item"}` });
    lines.push({ productId: p.id, name: p.name, price: p.price, quantity: qty, image: p.image });
  }
  const total = lines.reduce((sum, x) => sum + x.price * x.quantity, 0);
  lines.forEach(line => { const p = db.products.find(x => x.id === line.productId); p.stock -= line.quantity; });
  const order = { id: "BS" + Date.now(), userId: req.user.id, customerEmail: req.user.email, items: lines, total, address, phone, paymentMethod: paymentMethod || "Cash on delivery", status: "Pending", createdAt: new Date().toISOString() };
  db.orders.unshift(order); writeDB(db);
  res.status(201).json(order);
});
app.get("/api/my-orders", auth, (req, res) => res.json(readDB().orders.filter(o => o.userId === req.user.id)));
app.get("/api/admin/summary", auth, adminOnly, (_, res) => {
  const db = readDB();
  res.json({ products: db.products.length, orders: db.orders.length, customers: db.users.filter(u => u.role === "customer").length, revenue: db.orders.filter(o => o.status !== "Cancelled").reduce((s,o) => s + o.total, 0) });
});
app.get("/api/admin/products", auth, adminOnly, (_, res) => res.json(readDB().products));
app.post("/api/admin/products", auth, adminOnly, (req, res) => {
  const { name, description, category, price, stock, image } = req.body || {};
  if (!name || !category || !Number.isFinite(Number(price))) return res.status(400).json({ error: "Name, category and valid price are required." });
  const db = readDB();
  const p = { id: "p_" + Date.now(), name, description: description || "", category, price: Number(price), stock: Math.max(0, Number(stock) || 0), image: image || "", active: true };
  db.products.unshift(p); writeDB(db); res.status(201).json(p);
});
app.put("/api/admin/products/:id", auth, adminOnly, (req, res) => {
  const db = readDB(); const p = db.products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Product not found." });
  Object.assign(p, req.body, { price: Number(req.body.price ?? p.price), stock: Number(req.body.stock ?? p.stock) });
  writeDB(db); res.json(p);
});
app.delete("/api/admin/products/:id", auth, adminOnly, (req, res) => {
  const db = readDB(); const p = db.products.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "Product not found." });
  p.active = false; writeDB(db); res.json({ ok: true });
});
app.get("/api/admin/orders", auth, adminOnly, (_, res) => res.json(readDB().orders));
app.patch("/api/admin/orders/:id", auth, adminOnly, (req, res) => {
  const db = readDB(); const o = db.orders.find(x => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: "Order not found." });
  const allowed = ["Pending", "Confirmed", "Shipped", "Delivered", "Cancelled"];
  if (!allowed.includes(req.body.status)) return res.status(400).json({ error: "Invalid status." });
  o.status = req.body.status; writeDB(db); res.json(o);
});
app.get("/api/admin/customers", auth, adminOnly, (_, res) => res.json(readDB().users.filter(u => u.role === "customer").map(safeUser)));

async function ensureAdmin() {
  const email = process.env.ADMIN_EMAIL;
  const password = process.env.ADMIN_PASSWORD;
  if (!email || !password) return;
  const db = readDB();
  const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  if (!existing) {
    db.users.push({ id: "admin_" + Date.now(), name: "BibekShop Admin", email: email.toLowerCase(), phone: "", password: await bcrypt.hash(password, 10), role: "admin", createdAt: new Date().toISOString() });
    writeDB(db);
    console.log("Initial admin account created from environment settings.");
  } else if (existing.role !== "admin") {
    existing.role = "admin";
    writeDB(db);
  }
}
ensureAdmin().then(() => app.listen(PORT, () => console.log(`BibekShop running on http://localhost:${PORT}`))).catch(err => { console.error(err); process.exit(1); });
