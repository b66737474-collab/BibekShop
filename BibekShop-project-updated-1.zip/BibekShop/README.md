# BibekShop

A starter online shop with two separate web apps (Customer + Admin) connected to one Express API.

## Included
- Customer registration and login
- Product browsing, search and category filter
- Shopping cart and checkout
- Cash on delivery checkout
- Customer order history API
- Admin dashboard, product add/edit/soft-delete
- Admin order status updates and customer list
- Password hashing and JWT authentication

## Run locally
Requires Node.js 18+.

1. Extract this folder.
2. In this folder run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set a long random `JWT_SECRET`, plus your own `ADMIN_EMAIL` and strong `ADMIN_PASSWORD` in `.env`.
5. Run `npm start`. On first startup, the server creates the admin account automatically from those environment variables.
6. Open the admin app and sign in with those admin credentials.
7. Customer app: `http://localhost:3000/customer`
8. Admin app: `http://localhost:3000/admin`

Default sample products are included. No default admin password is shipped.

## Deploy online
Deploy the Node project to a Node.js host that supports persistent disk storage. Set environment variables from `.env.example`. The `database/db.json` file must be stored on persistent storage; ephemeral server filesystems can erase orders/users/products after redeploy. Use HTTPS in production.

## Important before real business use
This is a starter project, not yet a production commerce platform. Add a production database (PostgreSQL/MongoDB), image upload/storage, email/OTP verification, password reset, rate limiting, backups, privacy/terms pages, delivery integration and a verified payment gateway before taking real payments. Do not store card details. Cash on delivery is the only checkout method currently enabled.
